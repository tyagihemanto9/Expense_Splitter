---
name: Bug report
about: Create a report to help improve the app
title: ''
labels: bug
assignees: ''

---

<!-- READ THIS FIRST:
- Make sure you run the latest version of the app
- Make sure the bug you found is not already reported.
  DO NOT DELETE ANY TEXT from this template! All requested information is important.
-->

**Android version(s):**

**Device model(s):**

**Last working app version (if known):**

**Description of problem:**

**Screenshot or video of problem:**

**Additional information:**