package model

expect fun getSystemCurrencyCode(): String
