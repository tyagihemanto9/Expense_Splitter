object Constants {
    const val DATABASE_NAME = "recurring-expenses"
    const val DEFAULT_BACKUP_NAME = "$DATABASE_NAME.rexp"
    const val BACKUP_MIME_TYPE = "application/octet-stream"
    const val USER_PREFERENCES_DATA_STORE = "USER_PREFERENCES_DATA_STORE"
}
